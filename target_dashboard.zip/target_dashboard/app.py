"""
لوحة المعلومات التنفيذية — Target 2024 / 2025 / 2026
التشغيل:  streamlit run app.py
المصدر:   ورقة «Target» في الملف Total_2026.xlsb (البيانات مستخرجة في data/*.csv)
"""
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

import core
from core import CATS, MONTH_AR, PERIODS, YEARS

st.set_page_config(page_title="لوحة Target التنفيذية", page_icon="📊", layout="wide")

# ---------- RTL وتصميم نظيف ----------
st.markdown("""
<style>
html, body, [data-testid="stAppViewContainer"], [data-testid="stSidebar"], .block-container {direction: rtl; text-align: right;}
[data-testid="stMetric"] {background:#f6f8fa; border:1px solid #e1e6eb; border-radius:10px; padding:12px 16px;}
[data-testid="stMetricLabel"] {justify-content:flex-start;}
h1,h2,h3 {font-family: "Segoe UI", Tahoma, sans-serif;}
.note {background:#fff8e6; border-right:4px solid #e0a800; padding:8px 12px; border-radius:6px; font-size:0.9rem;}
</style>
""", unsafe_allow_html=True)

C_TGT, C_ACT, C_BAD, C_OK = "#9aa5b1", "#1f4e79", "#c0392b", "#2e8b57"
CAT_COLORS = {"Min": "#1f4e79", "Syn": "#2e8b57", "DEO": "#c0392b", "Fluids": "#e0a800"}


@st.cache_data
def get_data():
    m, ann, per, meta = core.load()
    return m, ann, per, meta, core.audit(m, ann, per)


m, ann, per, meta, audit = get_data()


def fmt(x, d=2):
    return "غير قابلة للحساب" if x is None else f"{x:,.{d}f}"


def layout(fig, title=None, h=380):
    fig.update_layout(title=title, height=h, barmode="group", font=dict(family="Segoe UI, Tahoma", size=13),
                      legend=dict(orientation="h", y=1.12), margin=dict(t=70, l=20, r=20, b=20),
                      plot_bgcolor="white", paper_bgcolor="white")
    fig.update_yaxes(gridcolor="#eef1f4")
    return fig


# ---------- المرشحات ----------
st.sidebar.header("المرشحات")
years = st.sidebar.multiselect("السنة", YEARS, default=YEARS) or YEARS
period = st.sidebar.selectbox("الفترة", list(PERIODS) + ["أشهر مخصصة"], index=list(PERIODS).index("السنة كاملة"))
if period == "أشهر مخصصة":
    months = st.sidebar.multiselect("الأشهر", list(MONTH_AR), default=list(MONTH_AR), format_func=MONTH_AR.get) or list(MONTH_AR)
else:
    months = list(PERIODS[period])
cats = st.sidebar.multiselect("فئة المنتج", CATS, default=CATS) or CATS
valid_only = st.sidebar.toggle("مقارنة الفترات المتطابقة (الأشهر المعتمدة فقط)", value=True,
                               help="يستبعد الأشهر بلا بيانات، وأبريل 2026 (صفر)، وأكتوبر 2026 (جارٍ)، ونوفمبر وديسمبر 2026 (مستقبلية).")
st.sidebar.caption("وحدة القياس غير محددة في المصدر. Total = مجموع الفئات المختارة.")

st.title("لوحة الأداء التنفيذية — Target")
st.caption(f"المصدر: {meta['source_file']} — ورقة «{meta['sheet']}» | تاريخ التحليل: {core.AS_OF} | الوحدة: {meta['unit']}")

ys = core.summarize(m, years, months, cats, valid_only)
cs = core.summarize(m, years, months, cats, valid_only, by="category")
ms = core.summarize(m, years, months, cats, valid_only=False, by="month")

if ys.empty:
    st.warning("لا توجد أشهر معتمدة ضمن هذا الاختيار. أوقف خيار «الأشهر المعتمدة فقط» أو غيّر الفترة.")

tabs = st.tabs(["الملخص التنفيذي", "مقارنة السنوات", "الأداء الشهري", "فئات المنتجات",
                "الأرباع ونصف السنوي", "جودة البيانات", "التوصيات", "الجداول"])

# ================= الملخص التنفيذي =================
with tabs[0]:
    if not ys.empty:
        cur = ys.sort_values("year").iloc[-1]
        y = int(cur.year)
        scope = f"{y} | {period} | {'أشهر معتمدة' if valid_only else 'كل الأشهر'} ({int(cur.n_months)} شهرًا)"
        st.subheader(f"مؤشرات {scope}")
        prev = [v for v in years if v < y]
        yo = core.yoy(m, y, max(prev), months, cats) if prev else None
        cat_y = cs[cs.year == y].dropna(subset=["pct"])
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("إجمالي الفعلي", fmt(cur.actual))
        c2.metric("إجمالي المستهدف", fmt(cur.target))
        c3.metric("نسبة التحقيق", ("غير قابلة للحساب" if pd.isna(cur.pct) else f"{cur.pct:.2f}%"))
        c4.metric("الفارق عن المستهدف", fmt(cur.gap), delta=f"{cur.gap:+.2f}")
        c5, c6, c7 = st.columns(3)
        if yo and yo["growth"] is not None:
            c5.metric(f"نمو الفعلي مقابل {max(prev)} (أشهر متناظرة)", f"{yo['growth']:.2f}%",
                      help="الأشهر: " + "، ".join(MONTH_AR[x] for x in yo["months"]))
        else:
            c5.metric("نمو الفعلي مقابل السنة السابقة", "لا توجد أشهر متناظرة")
        if not cat_y.empty:
            best = cat_y.sort_values("pct").iloc[-1]
            worst = cat_y.sort_values("pct").iloc[0]
            c6.metric("أفضل فئة أداءً", best.category, delta=f"{best.pct:.1f}%")
            c7.metric("أبرز نقطة تدخل (أدنى فئة)", worst.category, delta=f"{worst.pct:.1f}%", delta_color="inverse")
        st.markdown(f'<div class="note">النسبة السنوية المطبوعة في المصدر لعام 2026 هي '
                    f'{ann[ann.year==2026].printed_pct_total.iloc[0]*100:.2f}% وتقارن فعليًا جزئيًا بمستهدف يشمل أكتوبر–ديسمبر. '
                    f'الأرقام أعلاه محسوبة على أشهر متطابقة. التفاصيل في تبويب «جودة البيانات».</div>', unsafe_allow_html=True)
    st.markdown("#### أبرز الانحرافات")
    for r in core.build_recommendations(m, ann, per, audit)[:3]:
        st.write(f"- **{r['type']}:** {r['obs']}")

# ================= مقارنة السنوات =================
with tabs[1]:
    if not ys.empty:
        fig = go.Figure()
        fig.add_bar(x=ys.year.astype(str), y=ys.target, name="المستهدف", marker_color=C_TGT,
                    text=[f"{v:.2f}" for v in ys.target], textposition="outside")
        fig.add_bar(x=ys.year.astype(str), y=ys.actual, name="الفعلي", marker_color=C_ACT,
                    text=[f"{v:.2f}<br>({p:.1f}%)" if p is not None else f"{v:.2f}" for v, p in zip(ys.actual, ys.pct)],
                    textposition="outside")
        st.plotly_chart(layout(fig, "المستهدف مقابل الفعلي (النسبة بين قوسين = نسبة التحقيق)"), use_container_width=True)
        st.caption("الفترات الظاهرة: " + " | ".join(f"{int(r.year)}: {int(r.n_months)} أشهر" for r in ys.itertuples()))
        rows = []
        for y1 in sorted(years)[1:]:
            for y0 in [v for v in years if v < y1]:
                yo = core.yoy(m, y1, y0, months, cats)
                rows.append({"المقارنة": f"{y1} مقابل {y0}",
                             "الأشهر المتناظرة المعتمدة": "، ".join(MONTH_AR[x] for x in yo["months"]) if yo else "—",
                             f"الفعلي (الأحدث)": round(yo["new"], 2) if yo else None,
                             f"الفعلي (الأقدم)": round(yo["old"], 2) if yo else None,
                             "النمو %": round(yo["growth"], 2) if yo and yo["growth"] is not None else None})
        if rows:
            st.markdown("**نمو الفعلي على الأشهر المتناظرة فقط**")
            st.dataframe(rows, use_container_width=True, hide_index=True)
        mix = core.category_rank(m, years, months)
        if not mix.empty:
            fig2 = go.Figure()
            for c in cats:
                d = mix[mix.category == c]
                fig2.add_bar(x=d.year.astype(str), y=d.share, name=c, marker_color=CAT_COLORS[c],
                             text=[f"{v:.1f}%" for v in d.share], textposition="inside")
            fig2.update_layout(barmode="stack")
            st.plotly_chart(layout(fig2, "مزيج المبيعات الفعلية بين الفئات (% من الإجمالي)").update_layout(barmode="stack"),
                            use_container_width=True)

# ================= الأداء الشهري =================
with tabs[2]:
    if not ms.empty:
        fig = go.Figure()
        for y in sorted(years):
            d = ms[ms.year == y].sort_values("month")
            fig.add_scatter(x=d.month_ar, y=d.actual, mode="lines+markers", name=f"الفعلي {y}")
        st.plotly_chart(layout(fig, "اتجاه الفعلي الشهري (الأشهر غير المعتمدة تظهر بقيمها الأصلية؛ راجع الجدول)"),
                        use_container_width=True)
        for y in sorted(years):
            d = ms[ms.year == y].sort_values("month")
            fig = go.Figure()
            fig.add_bar(x=d.month_ar, y=d.target, name="المستهدف", marker_color=C_TGT)
            colors = [C_ACT if s == "ok" else "#c8cdd3" for s in d.status]
            fig.add_bar(x=d.month_ar, y=d.actual, name="الفعلي", marker_color=colors)
            st.plotly_chart(layout(fig, f"{y}: المستهدف مقابل الفعلي (الرمادي الفاتح = شهر غير معتمد)", 320),
                            use_container_width=True)
        good = ms[ms.status == "ok"].copy()
        good["pct"] = [core.pct(a, t) for a, t in zip(good.actual, good.target)]
        if not good.empty:
            b, w = good.loc[good.pct.idxmax()], good.loc[good.pct.idxmin()]
            st.success(f"أعلى نسبة تحقيق (أشهر معتمدة): {MONTH_AR[int(b.month)]} {int(b.year)} — {b.pct:.1f}%")
            st.error(f"أدنى نسبة تحقيق (أشهر معتمدة): {MONTH_AR[int(w.month)]} {int(w.year)} — {w.pct:.1f}%")
        st.dataframe([{"السنة": int(r.year), "الشهر": r.month_ar, "المستهدف": round(r.target, 2), "الفعلي": round(r.actual, 2),
                       "الفارق": round(r.actual - r.target, 2),
                       "نسبة التحقيق %": None if core.pct(r.actual, r.target) is None else round(core.pct(r.actual, r.target), 1),
                       "الحالة": core.STATUS_AR[r.status]} for r in ms.sort_values(["year", "month"]).itertuples()],
                     use_container_width=True, hide_index=True)

# ================= فئات المنتجات =================
with tabs[3]:
    if not cs.empty:
        for y in sorted(years):
            d = cs[cs.year == y]
            if d.empty:
                continue
            fig = go.Figure()
            fig.add_bar(x=d.category, y=d.target, name="المستهدف", marker_color=C_TGT)
            fig.add_bar(x=d.category, y=d.actual, name="الفعلي", marker_color=[C_OK if (p or 0) >= 100 else C_BAD for p in d.pct],
                        text=[f"{p:.1f}%" if p is not None else "—" for p in d.pct], textposition="outside")
            st.plotly_chart(layout(fig, f"{y}: الفئات — المستهدف والفعلي (أخضر ≥ 100%، أحمر < 100%)", 330), use_container_width=True)
        piv = cs.assign(pct=cs.pct.round(1)).pivot(index="category", columns="year", values="pct")
        st.markdown("**نسبة تحقيق كل فئة %**")
        st.dataframe(piv, use_container_width=True)

# ================= الأرباع ونصف السنوي =================
with tabs[4]:
    st.markdown('<div class="note">القيم هنا محسوبة من الأشهر المعتمدة فقط، ويظهر عدد الأشهر المعتمدة لكل فترة. '
                'قيم المصدر المطبوعة للأرباع/النصفين بها تعارضات (راجع جودة البيانات).</div>', unsafe_allow_html=True)
    rows = []
    for y in sorted(years):
        for p in ["Q1", "Q2", "Q3", "Q4", "H1", "H2"]:
            s = core.summarize(m, [y], list(PERIODS[p]), cats, valid_only=True)
            n = int(s.n_months.iloc[0]) if not s.empty else 0
            if s.empty:
                rows.append({"السنة": y, "الفترة": p, "أشهر معتمدة": f"0/{len(PERIODS[p])}", "المستهدف": None, "الفعلي": None, "الفارق": None, "التحقيق %": None})
            else:
                r = s.iloc[0]
                rows.append({"السنة": y, "الفترة": p, "أشهر معتمدة": f"{n}/{len(PERIODS[p])}", "المستهدف": round(r.target, 2),
                             "الفعلي": round(r.actual, 2), "الفارق": round(r.gap, 2),
                             "التحقيق %": None if r.pct is None else round(r.pct, 1)})
    qdf = pd.DataFrame(rows)
    st.dataframe(qdf, use_container_width=True, hide_index=True)
    plot = qdf.dropna(subset=["الفعلي"])
    for grp, labels in (("الأرباع", ["Q1", "Q2", "Q3", "Q4"]), ("النصفان", ["H1", "H2"])):
        d = plot[plot["الفترة"].isin(labels)]
        if d.empty:
            continue
        fig = go.Figure()
        for y in sorted(years):
            dd = d[d["السنة"] == y]
            fig.add_bar(x=dd["الفترة"], y=dd["التحقيق %"], name=str(y),
                        text=[f"{v:.1f}%" for v in dd["التحقيق %"]], textposition="outside")
        fig.add_hline(y=100, line_dash="dash", line_color="#555")
        st.plotly_chart(layout(fig, f"نسبة التحقيق — {grp} (على الأشهر المعتمدة)", 340), use_container_width=True)

# ================= جودة البيانات =================
with tabs[5]:
    st.subheader("مراجعة جودة البيانات والتحقق من الأرقام")
    cnt = audit["الحالة"].value_counts()
    a1, a2, a3, a4 = st.columns(4)
    a1.metric("متطابق", int(cnt.get("متطابق", 0)))
    a2.metric("فرق تقريبي", int(cnt.get("فرق تقريبي", 0)))
    a3.metric("بيانات غير مكتملة", int(cnt.get("بيانات غير مكتملة", 0)))
    a4.metric("تعارض يحتاج إلى مراجعة", int(cnt.get("تعارض يحتاج إلى مراجعة", 0)))
    st.markdown("**ملاحظات من فحص صيغ الخلايا في ورقة Target** (لم تُعدَّل أي قيمة في المصدر):")
    for cell, txt in core.FORMULA_FINDINGS:
        st.write(f"- `{cell}`: {txt}")
    st.markdown("**حالة الأشهر**")
    stt = m.groupby(["year", "status_ar"]).month_ar.apply(lambda s: "، ".join(s)).reset_index()
    stt.columns = ["السنة", "الحالة", "الأشهر"]
    st.dataframe(stt[stt["الحالة"] != core.STATUS_AR["ok"]], use_container_width=True, hide_index=True)
    sel = st.multiselect("تصفية جدول التدقيق حسب الحالة", sorted(audit["الحالة"].unique()), default=["تعارض يحتاج إلى مراجعة"])
    f = audit[audit["الحالة"].isin(sel)] if sel else audit
    st.dataframe(f, use_container_width=True, hide_index=True)
    st.download_button("تنزيل جدول التدقيق الكامل (CSV)", audit.to_csv(index=False).encode("utf-8-sig"), "audit.csv", "text/csv")

# ================= التوصيات =================
with tabs[6]:
    st.subheader("التوصيات الإدارية (حسب الأولوية)")
    st.caption("مبنية على الأشهر المعتمدة؛ لا تُنسب أسباب غير موجودة في الملف.")
    for r in core.build_recommendations(m, ann, per, audit):
        with st.expander(f"{r['p']}. [{r['type']}] {r['issue']}", expanded=r["p"] <= 3):
            st.write(f"**الملاحظة الرقمية:** {r['obs']}")
            st.write(f"**المشكلة/الفرصة:** {r['issue']}")
            st.write(f"**الإجراء المقترح:** {r['action']}")
            st.write(f"**مؤشر المتابعة:** {r['kpi']}")

# ================= الجداول =================
with tabs[7]:
    st.markdown("**الجدول الشهري الموحّد (القيم الأصلية كما وردت)**")
    show = m.drop(columns=["status_ar"]).rename(columns={"status": "status_code"})
    st.dataframe(show, use_container_width=True, hide_index=True)
    st.download_button("تنزيل الجدول الشهري (CSV)", m.to_csv(index=False).encode("utf-8-sig"), "target_monthly.csv", "text/csv")
    st.markdown("**الإجماليات السنوية كما وردت في المصدر**")
    st.dataframe(ann, use_container_width=True, hide_index=True)
    st.markdown("**الملخصات الربعية ونصف السنوية كما وردت في المصدر**")
    st.dataframe(per, use_container_width=True, hide_index=True)
