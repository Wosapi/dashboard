"""اختبار مستقل: يعيد حساب المؤشرات الرئيسية مباشرة من ملف xlsx المحوَّل ويقارنها بنتائج core.py.
التشغيل:  python tests/test_core.py /path/Total_2026.xlsx
"""
import sys
from pathlib import Path
from openpyxl import load_workbook

sys.path.insert(0, str(Path(__file__).parent.parent))
import core  # noqa: E402

ws = load_workbook(sys.argv[1], data_only=True)["Target "]
v = lambda r, c: ws.cell(row=r, column=c).value
num = lambda x: x if isinstance(x, (int, float)) else None
base = {2024: 3, 2025: 9, 2026: 15}
m, ann, per, _ = core.load()
valid = {(int(r.year), int(r.month)) for r in m.itertuples() if r.status == "ok"}
ok = True
for y, c0 in base.items():
    t = a = 0.0
    for mo in range(1, 13):
        if (y, mo) not in valid:
            continue
        t += sum(v(3 + 2 * (mo - 1), c0 + k) for k in range(4))
        a += sum(num(v(4 + 2 * (mo - 1), c0 + k)) or 0 for k in range(4))
    s = core.summarize(m, [y], range(1, 13), core.CATS).iloc[0]
    good = abs(s.target - t) < 1e-9 and abs(s.actual - a) < 1e-9
    ok &= good
    print(y, f"مستقل: target={t:.4f} actual={a:.4f} pct={a/t*100:.4f} | core: {s.target:.4f} {s.actual:.4f} {s.pct:.4f}", "OK" if good else "MISMATCH")
sys.exit(0 if ok else 1)
