"""
منطق البيانات والحسابات والتدقيق للوحة «Target».
لا يعتمد على Streamlit، لذلك يمكن اختباره مستقلًا.
القيم الأصلية تُقرأ من data/*.csv كما استُخرجت من المصدر، ولا تُعدَّل.
"""
from __future__ import annotations

import json
from datetime import date
from pathlib import Path

import numpy as np
import pandas as pd

DATA = Path(__file__).parent / "data"
CATS = ["Min", "Syn", "DEO", "Fluids"]
YEARS = [2024, 2025, 2026]
AS_OF = date(2026, 10, 26)  # تاريخ التحليل؛ يُستخدم للتمييز بين الأشهر المستقبلية والجزئية
MONTH_AR = {1: "يناير", 2: "فبراير", 3: "مارس", 4: "أبريل", 5: "مايو", 6: "يونيو",
            7: "يوليو", 8: "أغسطس", 9: "سبتمبر", 10: "أكتوبر", 11: "نوفمبر", 12: "ديسمبر"}
PERIODS = {"Q1": range(1, 4), "Q2": range(4, 7), "Q3": range(7, 10), "Q4": range(10, 13),
           "H1": range(1, 7), "H2": range(7, 13), "السنة كاملة": range(1, 13)}

STATUS_AR = {
    "ok": "معتمد",
    "no_data": "لا توجد بيانات فعلية",
    "verify": "بحاجة إلى تحقق (صفر في شهر منقضٍ)",
    "partial": "شهر جارٍ (قد يكون غير مكتمل)",
    "future": "شهر مستقبلي (لا بيانات بعد)",
}


# ------------------------------------------------------------------ التحميل
def load():
    m = pd.read_csv(DATA / "target_monthly.csv")
    ann = pd.read_csv(DATA / "target_annual_source.csv")
    per = pd.read_csv(DATA / "target_periods_source.csv")
    meta = json.loads((DATA / "meta.json").read_text(encoding="utf-8"))
    m = classify_months(m)
    return m, ann, per, meta


def classify_months(m: pd.DataFrame) -> pd.DataFrame:
    """يصنّف كل شهر: معتمد / لا بيانات / بحاجة إلى تحقق / جارٍ / مستقبلي."""
    m = m.copy()
    acols = [f"actual_{c}" for c in CATS]
    st = []
    for _, r in m.iterrows():
        vals = r[acols]
        y, mo = int(r.year), int(r.month)
        if isinstance(r.actual_text_note, str) or vals.isna().all():
            s = "no_data"
        elif y == AS_OF.year and mo > AS_OF.month:
            s = "future"
        elif y == AS_OF.year and mo == AS_OF.month:
            s = "partial"
        elif (vals.fillna(0) == 0).all():
            s = "verify"
        else:
            s = "ok"
        st.append(s)
    m["status"] = st
    m["status_ar"] = m["status"].map(STATUS_AR)
    m["month_ar"] = m["month"].map(MONTH_AR)
    return m


# ------------------------------------------------------------------ الحسابات
def pct(a, t):
    """نسبة التحقيق = الفعلي ÷ المستهدف × 100؛ None إذا كان المقام صفرًا."""
    return None if (t is None or pd.isna(t) or t == 0) else a / t * 100


def summarize(m, years, months, cats, valid_only=True, by="year"):
    """
    يجمع المستهدف والفعلي للأشهر والفئات المحددة.
    valid_only=True: يُحتسب المستهدف فقط للأشهر المعتمدة (مقارنة فترات متطابقة).
    by: "year" | "category" | "month"
    """
    d = m[m.year.isin(years) & m.month.isin(months)].copy()
    if valid_only:
        d = d[d.status == "ok"]
    rows = []
    if by == "category":
        for y in sorted(set(d.year)):
            for c in cats:
                dd = d[d.year == y]
                rows.append({"year": y, "category": c, "target": dd[f"target_{c}"].sum(),
                             "actual": dd[f"actual_{c}"].sum(), "n_months": len(dd)})
    elif by == "month":
        for (y, mo), dd in d.groupby(["year", "month"]):
            rows.append({"year": y, "month": mo, "month_ar": MONTH_AR[mo],
                         "target": sum(dd[f"target_{c}"].sum() for c in cats),
                         "actual": np.nan if dd.status.iloc[0] in ("no_data", "future")
                         else sum(dd[f"actual_{c}"].sum() for c in cats),
                         "status": dd.status.iloc[0]})
    else:
        for y, dd in d.groupby("year"):
            rows.append({"year": y, "target": sum(dd[f"target_{c}"].sum() for c in cats),
                         "actual": sum(dd[f"actual_{c}"].sum() for c in cats), "n_months": len(dd)})
    out = pd.DataFrame(rows)
    if out.empty:
        return out
    out["gap"] = out.actual - out.target
    out["pct"] = [pct(a, t) for a, t in zip(out.actual, out.target)]
    return out


def common_months(m, y_a, y_b, months):
    """الأشهر المعتمدة في السنتين معًا ضمن الفترة المختارة (للمقارنة العادلة)."""
    ok = lambda y: set(m[(m.year == y) & (m.status == "ok") & m.month.isin(months)].month)
    return sorted(ok(y_a) & ok(y_b))


def yoy(m, y_new, y_old, months, cats):
    cm = common_months(m, y_new, y_old, months)
    if not cm:
        return None
    f = lambda y: sum(m[(m.year == y) & m.month.isin(cm)][f"actual_{c}"].sum() for c in cats)
    new, old = f(y_new), f(y_old)
    return {"months": cm, "new": new, "old": old, "growth": None if old == 0 else (new - old) / old * 100}


def category_rank(m, years, months):
    s = summarize(m, years, months, CATS, by="category")
    if s.empty:
        return s
    tot = s.groupby("year").actual.transform("sum")
    s["share"] = s.actual / tot * 100
    return s


# ------------------------------------------------------------------ التدقيق
def _status(src, calc, kind="val", incomplete=False):
    if src is None or calc is None or pd.isna(src) or pd.isna(calc):
        return "بيانات غير مكتملة"
    d = abs(src - calc)
    lo, hi = (0.005, 0.05) if kind == "val" else (0.0005, 0.005)
    if d <= lo:
        return "بيانات غير مكتملة" if incomplete else "متطابق"
    if d <= hi:
        return "فرق تقريبي"
    return "تعارض يحتاج إلى مراجعة"


def audit(m, ann, per):
    rows = []

    def add(period, ind, src, calc, kind="val", incomplete=False, note=""):
        diff = None if (src is None or calc is None or pd.isna(src) or pd.isna(calc)) else src - calc
        rows.append({"الفترة": period, "المؤشر": ind,
                     "القيمة في المصدر": src, "القيمة المحسوبة": calc, "الفرق": diff,
                     "الحالة": _status(src, calc, kind, incomplete), "ملاحظة": note})

    # (1) الجدول الشهري: الإجمالي مقابل مجموع الفئات، والنسبة المطبوعة مقابل المحسوبة
    for _, r in m.iterrows():
        p = f"{r.year}-{r.month:02d} {r.month_name}"
        add(p, "Target: الإجمالي مقابل مجموع الفئات", r.target_Total, sum(r[f"target_{c}"] for c in CATS))
        if r.status != "no_data":
            add(p, "Actual: الإجمالي مقابل مجموع الفئات", r.actual_Total, sum(r[f"actual_{c}"] for c in CATS),
                incomplete=r.status in ("verify", "partial", "future"),
                note="" if r.status == "ok" else STATUS_AR[r.status])
            add(p, "% المطبوعة مقابل Actual÷Target", r.printed_pct_total,
                (r.actual_Total / r.target_Total) if r.target_Total else None, kind="pct")
        else:
            add(p, "Actual", None, None, note=STATUS_AR["no_data"] + (f" ({r.actual_text_note})" if isinstance(r.actual_text_note, str) else ""))

    # (2) الإجمالي السنوي مقابل مجموع الأشهر
    for _, a in ann.iterrows():
        y = int(a.year)
        d = m[m.year == y]
        incomplete = (d.status != "ok").any()
        for c in CATS + ["Total"]:
            cols = CATS if c == "Total" else [c]
            add(f"{y} سنوي", f"Target {c}: المصدر مقابل مجموع الأشهر", a[f"target_{c}"],
                sum(d[f"target_{k}"].sum() for k in cols))
            add(f"{y} سنوي", f"Actual {c}: المصدر مقابل مجموع الأشهر", a[f"actual_{c}"],
                sum(d[f"actual_{k}"].sum() for k in cols), incomplete=incomplete,
                note="أشهر غير معتمدة: " + ", ".join(f"{MONTH_AR[mo]}({s})" for mo, s in
                                                     zip(d[d.status != 'ok'].month, d[d.status != 'ok'].status)) if incomplete else "")
        add(f"{y} سنوي", "% السنوية المطبوعة مقابل Actual÷Target (المصدر)", a.printed_pct_total,
            a.actual_Total / a.target_Total, kind="pct", incomplete=incomplete,
            note="النسبة تقارن فعليًا جزئيًا بمستهدف سنة كاملة" if incomplete else "")
        for c in CATS:  # صف YTD Target
            if not pd.isna(a[f"ytd_row_{c}"]):
                add(f"{y} سنوي", f"صف YTD Target ({c}) مقابل Actual÷Target", a[f"ytd_row_{c}"],
                    a[f"actual_{c}"] / a[f"target_{c}"], kind="pct", incomplete=incomplete)

    # (3) الأرباع ونصف السنوي مقابل مجموع الأشهر + النسب المطبوعة
    for _, r in per.iterrows():
        y, p = int(r.year), r.period
        d = m[(m.year == y) & m.month.isin(list(PERIODS[p]))]
        incomplete = (d.status != "ok").any()
        inc_note = "أشهر غير معتمدة: " + ", ".join(f"{MONTH_AR[mo]}" for mo in d[d.status != 'ok'].month) if incomplete else ""
        for c in CATS + ["Total"]:
            cols = CATS if c == "Total" else [c]
            add(f"{y} {p}", f"Target {c}: المصدر مقابل مجموع الأشهر", r[f"target_{c}"],
                sum(d[f"target_{k}"].sum() for k in cols))
            add(f"{y} {p}", f"Actual {c}: المصدر مقابل مجموع الأشهر", r[f"actual_{c}"],
                sum(d[f"actual_{k}"].sum() for k in cols), incomplete=incomplete, note=inc_note)
            add(f"{y} {p}", f"% {c} المطبوعة مقابل Actual÷Target (المصدر)", r[f"printed_pct_{c}"],
                (r[f"actual_{c}"] / r[f"target_{c}"]) if r[f"target_{c}"] else None, kind="pct",
                incomplete=incomplete, note=inc_note)
    # H مقابل مجموع الأرباع
    pp = per.set_index(["year", "period"])
    for y in YEARS:
        for h, qs in (("H1", ("Q1", "Q2")), ("H2", ("Q3", "Q4"))):
            for kind_ in ("target", "actual"):
                src = pp.loc[(y, h), f"{kind_}_Total"]
                calc = sum(pp.loc[(y, q), f"{kind_}_Total"] for q in qs)
                add(f"{y} {h}", f"{kind_.capitalize()} Total: المصدر مقابل مجموع الربعين", src, calc)
    # (4) الإجمالي السنوي مقابل مجموع الأرباع الأربعة في المصدر
    for _, a in ann.iterrows():
        y = int(a.year)
        for c in CATS + ["Total"]:
            for kind_ in ("target", "actual"):
                calc = sum(pp.loc[(y, q), f"{kind_}_{c}"] for q in ("Q1", "Q2", "Q3", "Q4"))
                add(f"{y} سنوي", f"{kind_.capitalize()} {c}: المصدر مقابل مجموع الأرباع", a[f"{kind_}_{c}"], calc,
                    incomplete=False)
    return pd.DataFrame(rows)


def summary_counts(a: pd.DataFrame) -> pd.Series:
    return a["الحالة"].value_counts()


# ------------------------------------------------------------------ ملاحظات من فحص صيغ الخلايا في المصدر
FORMULA_FINDINGS = [
    ("G14", "إجمالي Actual لشهر يونيو 2024 = مجموع الفئات + 0.08 (قيمة مضافة يدويًا داخل الصيغة)."),
    ("D41:G41", "Q3 2024 (Actual) يجمع أغسطس وسبتمبر فقط ويستثني يوليو، بينما إجمالي 2024 السنوي يتضمن يوليو."),
    ("D32:G32", "Q1 2024 (Target) أصفار ثابتة، بينما الجدول الشهري يتضمن مستهدفات يناير–مارس 2024."),
    ("D36:G36", "Q2 2024 (Target) يجمع مايو ويونيو فقط ويستثني أبريل."),
    ("E38:G38", "نسب Q2 2024 المطبوعة منزاحة عمودًا واحدًا: Syn تكرر نسبة Min، وDEO تعرض نسبة Syn، وFluids تعرض نسبة DEO."),
    ("L40:M40", "Q3 2025 (Target) يجمع أغسطس وسبتمبر فقط ويستثني يوليو (الذي سُجّل فيه Vacation)، بينما الإجمالي السنوي 2025 يتضمنه."),
    ("S36:S36", "Q2 2026 (Target) يجمع مايو ويونيو فقط ويستثني أبريل؛ ولذلك مستهدف 2026 السنوي (76.79) أقل من مجموع الأشهر (84.07) بمقدار مستهدف أبريل (7.28)."),
    ("S28:T29", "نسبة 2026 السنوية (74.82%) تقارن فعلي حتى أكتوبر بمستهدف يشمل نوفمبر وديسمبر (أشهر لم تأتِ بعد)."),
]


def build_recommendations(m, ann, per, a):
    """توصيات مبنية على أرقام محسوبة (فترات متطابقة: الأشهر المعتمدة فقط). لا تنسب أسبابًا غير موجودة في الملف."""
    allm = range(1, 13)
    ys = summarize(m, YEARS, allm, CATS).set_index("year")
    cs = summarize(m, YEARS, allm, CATS, by="category")
    g = lambda y, c, col: float(cs[(cs.year == y) & (cs.category == c)][col].iloc[0])
    conflicts = int((a["الحالة"] == "تعارض يحتاج إلى مراجعة").sum())
    src26 = float(ann[ann.year == 2026].printed_pct_total.iloc[0]) * 100
    y26 = ys.loc[2026]
    r = []
    r.append(dict(p=1, type="مسألة بيانات", obs=f"نسبة 2026 المطبوعة في المصدر {src26:.2f}% مقابل {y26.pct:.2f}% للأشهر المعتمدة ({int(y26.n_months)} أشهر: فعلي {y26.actual:.2f} من مستهدف {y26.target:.2f}). الفرق سببه إدراج مستهدف أكتوبر (فعلي جزئي) ونوفمبر وديسمبر (لم يأتيا بعد) في مقام النسبة المطبوعة؛ أما مستهدف أبريل فمستبعد أصلًا من مستهدف 2026 في المصدر.",
                  issue="النسبة السنوية المطبوعة تظهر عجزًا لا يعكس أداء الأشهر المنقضية.",
                  action="اعتماد نسبة تحقيق للفترة المتطابقة (YTD) في التقارير الدورية بدل مقارنة الفعلي الجزئي بمستهدف السنة كاملة.", kpi="نسبة التحقيق على الأشهر المعتمدة فقط"))
    r.append(dict(p=2, type="مسألة بيانات", obs=f"{conflicts} تعارضًا حسابيًا في المصدر (إجماليات سنوية/ربعية/نصفية لا تتطابق مع مجموع الأشهر، ونسب Q2 2024 منزاحة، وزيادة 0.08 يدوية في يونيو 2024).",
                  issue="اختلاف الإجماليات بين الأرباع والسنة يهدد موثوقية أي مقارنة.",
                  action="مراجعة صيغ الخلايا المذكورة في تبويب جودة البيانات وتصحيحها في الملف المصدر قبل الاعتماد على الإجماليات المطبوعة.", kpi="عدد التعارضات في جدول التدقيق (الهدف: 0)"))
    r.append(dict(p=3, type="فجوة أداء", obs=f"DEO: تحقيق {g(2026,'DEO','pct'):.1f}% في 2026 (فعلي {g(2026,'DEO','actual'):.2f} من {g(2026,'DEO','target'):.2f}، فارق {g(2026,'DEO','gap'):.2f})، و{g(2025,'DEO','pct'):.1f}% في 2025، و{g(2024,'DEO','pct'):.1f}% في 2024.",
                  issue="فئة DEO دون مستهدفها في السنوات الثلاث، وهي صاحبة أكبر مستهدف في الجدول.",
                  action="فتح تحقيق في أسباب العجز (غير محددة في الملف) ومقارنة مستوى المستهدف بالأداء الفعلي المتكرر.", kpi="نسبة تحقيق DEO الشهرية"))
    r.append(dict(p=4, type="فجوة أداء", obs=f"Fluids: {g(2026,'Fluids','pct'):.1f}% في 2026 (فارق {g(2026,'Fluids','gap'):.2f}) بعد {g(2025,'Fluids','pct'):.1f}% في 2025.",
                  issue="الفئة تحولت من تجاوز طفيف للمستهدف إلى عجز.",
                  action="متابعة شهرية للفئة وتحديد الأشهر التي سبّبت التراجع؛ السبب غير معروف ويحتاج إلى تحقيق إضافي.", kpi="نسبة تحقيق Fluids الشهرية"))
    r.append(dict(p=5, type="نقطة قوة", obs=f"Syn: {g(2026,'Syn','pct'):.1f}% في 2026، وحصتها من الفعلي ارتفعت من {cs[(cs.year==2024)&(cs.category=='Syn')].actual.iloc[0]/cs[cs.year==2024].actual.sum()*100:.1f}% (2024) إلى {g(2026,'Syn','actual')/cs[cs.year==2026].actual.sum()*100:.1f}% (2026). Min: {g(2026,'Min','pct'):.1f}% وحصتها {g(2026,'Min','actual')/cs[cs.year==2026].actual.sum()*100:.1f}%.",
                  issue="Min وSyn تتجاوزان مستهدفهما وتعوّضان جزءًا من عجز DEO وFluids.",
                  action="الحفاظ على الأداء ودراسة إمكانية رفع مستهدف Syn وMin إن أكدت المراجعة أن مستهدفاتهما منخفضة نسبيًا (Min حققت %.0f%% من مستهدفها في 2025)." % g(2025, 'Min', 'pct'), kpi="تحقيق Min وSyn ومساهمتهما في الإجمالي"))
    r.append(dict(p=6, type="مراجعة بيانات", obs="أبريل 2026 مسجّل صفرًا (شهر منقضٍ)، وأكتوبر 2026 فعلي جزئي (Syn = 0)، ويوليو 2025 مكتوب Vacation، وأشهر يناير–أبريل 2024 بلا فعلي.",
                  issue="فجوات تمنع مقارنة سنوية كاملة وتُضعف دقة الاتجاه.",
                  action="تأكيد ما إذا كان أبريل 2026 صفرًا حقيقيًا أم بيانات غير مدخلة، واستكمال أكتوبر بعد إقفاله، وتوثيق وضع يوليو 2025.", kpi="نسبة الأشهر المنقضية ذات البيانات المعتمدة"))
    yo = yoy(m, 2026, 2025, allm, CATS)
    if yo:
        r.append(dict(p=7, type="فرصة تحسين", obs=f"نمو الفعلي 2026 مقابل 2025 للأشهر المتناظرة المعتمدة ({', '.join(MONTH_AR[x] for x in yo['months'])}): {yo['growth']:.2f}% ({yo['old']:.2f} → {yo['new']:.2f}).",
                      issue="النمو على الأشهر المتناظرة محدود (فرق صغير بين السنتين).",
                      action="متابعة النمو على الأشهر المتناظرة شهريًا وربطه بمزيج الفئات.", kpi="نمو الفعلي مقابل الشهر المناظر"))
    return r
