"""
استخراج بيانات ورقة «Target» من ملف Total_2026 إلى ملفات CSV منظّمة.

الاستخدام:
    python extract_data.py Total_2026.xlsx

ملاحظة: الملف الأصلي بصيغة .xlsb. حوّله أولًا إلى .xlsx (Excel: حفظ باسم، أو LibreOffice)
ثم شغّل هذا السكربت. القيم تُقرأ كما هي دون تعديل أو تقريب.
"""
import json
import sys
from pathlib import Path

import pandas as pd
from openpyxl import load_workbook

SHEET = "Target "  # الاسم الأصلي للورقة (يحتوي على مسافة في النهاية)
CATS = ["Min", "Syn", "DEO", "Fluids"]
YEARS = {2024: 3, 2025: 9, 2026: 15}  # العمود الأول (Min) لكل سنة في الجدول الشهري
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
OUT = Path(__file__).parent / "data"


def num(v):
    """يعيد الرقم كما هو، أو None إذا كانت الخلية فارغة أو نصية."""
    return float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def main(path):
    wb = load_workbook(path, data_only=True)
    ws = wb[SHEET]
    cell = lambda r, c: ws.cell(row=r, column=c).value

    # ---------- 1) الجدول الشهري ----------
    rows, notes = [], []
    for y, c0 in YEARS.items():
        for i, m in enumerate(MONTHS):
            rt, ra = 3 + 2 * i, 4 + 2 * i
            raw_a = [cell(ra, c0 + k) for k in range(5)]
            text_note = next((str(v).strip() for v in raw_a if isinstance(v, str)), None)
            if text_note:
                notes.append({"year": y, "month": i + 1, "text_in_actual_cells": text_note})
            rows.append({
                "year": y, "month": i + 1, "month_name": m,
                **{f"target_{k}": num(cell(rt, c0 + j)) for j, k in enumerate(CATS + ["Total"])},
                **{f"actual_{k}": num(cell(ra, c0 + j)) for j, k in enumerate(CATS + ["Total"])},
                "printed_pct_total": num(cell(ra, c0 + 5)),
                "actual_text_note": text_note,
            })
    pd.DataFrame(rows).to_csv(OUT / "target_monthly.csv", index=False)

    # ---------- 2) الإجمالي السنوي كما ورد في المصدر (صفوف 27-29) ----------
    ann = []
    for y, c0 in YEARS.items():
        ann.append({
            "year": y,
            **{f"target_{k}": num(cell(27, c0 + j)) for j, k in enumerate(CATS + ["Total"])},
            **{f"actual_{k}": num(cell(28, c0 + j)) for j, k in enumerate(CATS + ["Total"])},
            "printed_pct_total": num(cell(28, c0 + 5)),
            **{f"ytd_row_{k}": num(cell(29, c0 + j)) for j, k in enumerate(CATS + ["Total"])},
        })
    pd.DataFrame(ann).to_csv(OUT / "target_annual_source.csv", index=False)

    # ---------- 3) الملخصات الربعية ونصف السنوية كما وردت في المصدر ----------
    blocks = [("Q1", 31), ("Q2", 35), ("Q3", 39), ("Q4", 43), ("H1", 48), ("H2", 52)]
    lab_cols = {2024: 3, 2025: 9, 2026: 15}  # عمود تسمية الفترة؛ القيم في الأعمدة الخمسة التالية
    per = []
    for name, r in blocks:
        for y, lc in lab_cols.items():
            vals = {k: [num(cell(r + 1 + t, lc + 1 + j)) for t in range(3)] for j, k in enumerate(CATS + ["Total"])}
            row = {"year": y, "period": name}
            for k in CATS + ["Total"]:
                row[f"target_{k}"], row[f"actual_{k}"], row[f"printed_pct_{k}"] = vals[k]
            per.append(row)
    pd.DataFrame(per).to_csv(OUT / "target_periods_source.csv", index=False)

    (OUT / "meta.json").write_text(json.dumps({
        "source_file": Path(path).name, "sheet": SHEET.strip(), "text_notes": notes,
        "unit": "غير محددة في المصدر",
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print("تم الاستخراج:", [p.name for p in OUT.iterdir()])


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "Total_2026.xlsx")
